#!/usr/bin/env node
/**
 * Push the whole project to Mavrin007/fitplan-hub via the GitHub Git Data API.
 *
 * Works in sandboxes where the git CLI is blocked (Vly manages version control),
 * as long as the GitHub REST API is reachable and a token with Contents
 * read/write is available.
 *
 * Usage:
 *   GITHUB_TOKEN=<token> node scripts/push-to-github.mjs "commit message"
 *   node scripts/push-to-github.mjs <token> "commit message"   (token as argv)
 *
 * Behavior:
 *   - Walks the project, skipping build artifacts and secrets (same rules as
 *     .gitignore).
 *   - Computes git blob SHAs locally (sha1 of "blob <size>\0<content>"), so
 *     unchanged files are never re-uploaded between runs.
 *   - Uploads blobs one at a time with pacing to stay under GitHub's
 *     secondary rate limits, retrying with exponential backoff.
 *   - Resumable: progress is persisted to /tmp/github-push-progress.json, so
 *     re-running after a rate-limit stall continues where it left off.
 *   - Builds a FULL tree (no base_tree) — this both removes files that are
 *     missing locally and avoids the sha:null trick (which the API rejects).
 *
 * Known GitHub API limitations handled here:
 *   - Files under .github/workflows/ cannot be created or updated via the
 *     REST API (GitHub returns 404 to prevent supply-chain attacks). They are
 *     kept at their current remote revision instead of being overwritten.
 *   - Files that only exist remotely but are required by those workflows
 *     (e.g. package-lock.json, scripts/e2e-setup-convex.mjs) are preserved.
 */
import { createHash } from "node:crypto";
import { readFile, readdir, writeFile } from "node:fs/promises";
import { join, relative, sep } from "node:path";

// Token may come from the GITHUB_TOKEN env var, or (sandbox-safe) from argv.
const TOKEN = process.env.GITHUB_TOKEN || process.argv[2];
if (!TOKEN) {
  console.error("GITHUB_TOKEN env variable or token argv is required");
  process.exit(1);
}
// [diag] fingerprint only — never prints the secret itself.
console.log(`[diag] token prefix: ${TOKEN.slice(0, 4)}… length: ${TOKEN.length}`);

const REPO = "Mavrin007/fitplan-hub";
const API = "https://api.github.com";
const ROOT = process.cwd();
// If argv[2] was consumed as the token, the message lives at argv[3].
const MESSAGE = process.env.GITHUB_TOKEN
  ? process.argv[2] || "chore: sync project state"
  : process.argv[3] || "chore: sync project state";
const PROGRESS_FILE = "/tmp/github-push-progress.json";

// Same exclusions as .gitignore (+ platform build artifacts).
const EXCLUDE_DIRS = new Set([
  "node_modules", "dist", ".git", ".vercel", ".freebuff", "isolate",
  "test-results", "coverage", "e2e-live",
]);
const EXCLUDE_FILES = new Set([
  ".env", ".env.local", ".env.production", ".env.development",
  "desktop-v2.db", "desktop-v2.db-shm", "desktop-v2.db-wal",
  "main.ts", "sst-env.d.ts", "push-to-github.mjs",
]);
const EXCLUDE_EXT = new Set([".pem", ".key"]);

// Never try to write these paths: GitHub REST API rejects .github/workflows/*
// and the workflows on the remote reference these files, so deleting them
// would break CI. Kept at their current remote revision.
const PRESERVE_REMOTE = new Set([
  "package-lock.json",
  "scripts/e2e-setup-convex.mjs",
]);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function gitBlobSha(buf) {
  const header = Buffer.from(`blob ${buf.length}\0`, "utf8");
  return createHash("sha1").update(header).update(buf).digest("hex");
}

async function listFiles(dir) {
  const out = [];
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    if (entry.isDirectory()) {
      if (EXCLUDE_DIRS.has(entry.name)) continue;
      out.push(...(await listFiles(join(dir, entry.name))));
    } else {
      if (EXCLUDE_FILES.has(entry.name)) continue;
      if (entry.name.startsWith("diag-tree") && entry.name.endsWith(".mjs")) continue;
      const ext = entry.name.slice(entry.name.lastIndexOf("."));
      if (EXCLUDE_EXT.has(ext)) continue;
      const abs = join(dir, entry.name);
      out.push({ abs, rel: relative(ROOT, abs).split(sep).join("/") });
    }
  }
  return out;
}

async function gh(path, opts = {}) {
  const res = await fetch(API + path, {
    ...opts,
    headers: {
      Authorization: `Bearer ${TOKEN}`,
      Accept: "application/vnd.github+json",
      "User-Agent": "fitplan-hub-push",
      ...(opts.headers || {}),
    },
  });
  const text = await res.text();
  if (!res.ok) {
    throw new Error(`GitHub ${res.status} ${path}: ${text.slice(0, 400)}`);
  }
  return text ? JSON.parse(text) : null;
}

async function ghRetry(path, opts = {}, retries = 5) {
  for (let attempt = 0; ; attempt++) {
    try {
      return await gh(path, opts);
    } catch (err) {
      const m = /^GitHub (\d+) /.exec(err.message);
      const status = m ? Number(m[1]) : 0;
      const retryable = status === 403 || status === 429 || status >= 500 || status === 404;
      if (!retryable || attempt >= retries) throw err;
      const wait = Math.min(30000, 5000 * 2 ** attempt) + Math.floor(Math.random() * 2000);
      process.stdout.write(`retry ${attempt + 1} (${status}) on ${path} in ${Math.round(wait / 1000)}s\n`);
      await sleep(wait);
    }
  }
}

async function readProgress() {
  try {
    const raw = await readFile(PROGRESS_FILE, "utf8");
    return new Set(JSON.parse(raw));
  } catch {
    return new Set();
  }
}

async function saveProgress(done) {
  await writeFile(PROGRESS_FILE, JSON.stringify([...done]));
}

async function main() {
  const files = await listFiles(ROOT);
  // Files we will try to write ourselves (everything except workflows).
  const writable = files.filter((f) => !f.rel.startsWith(".github/workflows/"));
  console.log(`files to push: ${writable.length} (${files.length - writable.length} workflow files preserved)`);

  const repo = await gh(`/repos/${REPO}`);
  const branch = repo.default_branch;
  console.log(`branch: ${branch}`);

  const ref = await gh(`/repos/${REPO}/git/ref/heads/${branch}`);
  const headSha = ref.object.sha;
  const tree = await gh(`/repos/${REPO}/git/trees/${headSha}?recursive=1`);
  const remoteBlobs = (tree.tree ?? []).filter((t) => t.type === "blob");
  console.log(`head: ${headSha} (${remoteBlobs.length} remote files)`);

  // Build full tree entries: local writable files + preserved remote files.
  const done = await readProgress();
  const entries = [];
  let uploaded = 0;
  for (const f of writable) {
    const buf = await readFile(f.abs);
    const sha = gitBlobSha(buf);
    if (done.has(sha)) {
      entries.push({ path: f.rel, mode: "100644", type: "blob", sha });
      continue;
    }
    const blob = await ghRetry(`/repos/${REPO}/git/blobs`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content: buf.toString("base64"), encoding: "base64" }),
    });
    done.add(sha);
    await saveProgress(done);
    uploaded++;
    entries.push({ path: f.rel, mode: "100644", type: "blob", sha: blob.sha });
    if (uploaded % 3 === 0) await sleep(1500); // stay under secondary rate limits
    process.stdout.write(`blobs: ${uploaded} new / ${entries.length} total\r`);
  }
  console.log(`\nblob upload done (${uploaded} newly uploaded, ${entries.length} local entries)`);

  // Preserve remote files we must not delete (workflows + CI dependencies).
  const localPaths = new Set(writable.map((f) => f.rel));
  let preserved = 0;
  for (const item of remoteBlobs) {
    const keep =
      item.path.startsWith(".github/workflows/") ||
      PRESERVE_REMOTE.has(item.path);
    if (keep && !localPaths.has(item.path)) {
      entries.push({ path: item.path, mode: item.mode, type: "blob", sha: item.sha });
      preserved++;
    }
  }
  console.log(`preserved remote files: ${preserved}`);
  console.log(`tree entries total: ${entries.length}`);

  const treeRes = await ghRetry(`/repos/${REPO}/git/trees`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ tree: entries }),
  });

  const commit = await ghRetry(`/repos/${REPO}/git/commits`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      message: MESSAGE,
      tree: treeRes.sha,
      parents: [headSha],
    }),
  });

  await ghRetry(`/repos/${REPO}/git/refs/heads/${branch}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ sha: commit.sha, force: false }),
  });

  console.log("pushed commit:", commit.sha);
  console.log(`https://github.com/${REPO}/commit/${commit.sha}`);
}

main().catch((err) => {
  console.error(err.message);
  process.exit(1);
});
