import { beforeEach, describe, expect, it, vi } from "vitest";
import { screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";

// Мок convex-слоя: стабильные ссылки на функции вместо anyApi-Proxy.
vi.mock("convex/react", () => import("@/test/convex-react-mock"));
vi.mock("@/convex/_generated/api", () => import("@/test/convex-react-mock"));
vi.mock("sonner", () => import("@/test/sonner-mock"));

import { api, setQuery } from "@/test/convex-react-mock";
import { resetMocks, renderWithRouter } from "@/test/utils";
import { profile, type MealEntry, type WeightEntry } from "@/test/fixtures";
import { lastNDays, toDateKey, todayKey } from "@/lib/dates";
import Progress from "./Progress";

/** Диапазон периода — как в компоненте (lastNDays(period)). */
function mealRange(period = 30): { from: string; to: string } {
  const days = lastNDays(period);
  return { from: days[0], to: days[days.length - 1] };
}

const ALL_MEALS_RANGE = { from: "0000-01-01", to: "9999-12-31" };

/** Мок всех диапазонов mealLog, включая 7/30/90 дней — смена периода
 *  меняет args запроса, и без заданного результата мок вернул бы
 *  undefined (компонент ушёл бы в скелетон). */
function seedMealRanges(meals: MealEntry[] = []) {
  // График калорий/макросов считает итоги на сервере (getDailyTotals) —
  // мокаем агрегат по дням для каждого периода, а не полные записи.
  for (const p of [7, 30, 90]) {
    setQuery(api.mealLog.getDailyTotals, mealRange(p), toTotals(meals));
  }
  // Экспорт «Питание (N)» по-прежнему тянет все записи за всё время.
  setQuery(api.mealLog.getByRange, ALL_MEALS_RANGE, meals);
}

/** Сворачивает записи дневника в итоги дня (как convex/mealLog.getDailyTotals). */
function toTotals(meals: MealEntry[]) {
  const byDate = new Map<string, { calories: number; protein: number; carbs: number; fat: number; count: number }>();
  for (const e of meals) {
    const cur = byDate.get(e.date) ?? { calories: 0, protein: 0, carbs: 0, fat: 0, count: 0 };
    cur.calories += e.calories;
    cur.protein += e.protein;
    cur.carbs += e.carbs;
    cur.fat += e.fat;
    cur.count += 1;
    byDate.set(e.date, cur);
  }
  return [...byDate.entries()].map(([date, t]) => ({ date, ...t }));
}

function mealEntry(
  id: string,
  date: string,
  calories: number,
  protein = 10,
  carbs = 20,
  fat = 5,
): MealEntry {
  return {
    _id: id,
    userId: "u1",
    createdAt: 0,
    date,
    mealType: "lunch",
    name: "Обед",
    quantity: 1,
    calories,
    protein,
    carbs,
    fat,
  };
}

function weightEntry(date: string, weightKg: number): WeightEntry {
  return { _id: `w-${date}`, userId: "u1", createdAt: 0, date, weightKg };
}

/** Пустые списки воды и своих продуктов (кнопки экспорта «Вода (0)» и
 *  «Продукты (0)» без них ушли бы в скелетон). */
function seedEmptyWaterAndFoods() {
  setQuery(api.water.listMyWater, { limit: 730 }, []);
  setQuery(api.foods.listMyFoods, {}, []);
}

/** Итоги недели: пустая сводка (секция показывает empty-state). */
function seedWeeklyDigest() {
  setQuery(api.digest.getMyWeeklyDigest, undefined, {
    hasData: false,
    trackedDays: 0,
    weightStartKg: null,
    weightEndKg: null,
    weightDeltaKg: null,
    avgCalories: null,
    avgProteinG: null,
    caloriePct: null,
    workoutCount: 0,
    tonnageKg: 0,
    avgWaterMl: null,
  });
}

/** Профиль + пустые данные: все графики показывают EmptyChart. */
function setupEmpty() {
  setQuery(api.profiles.getMyProfile, undefined, profile);
  setQuery(api.weightEntries.listMyWeights, { limit: 730 }, []);
  setQuery(api.workouts.listLogs, { limit: 500 }, []);
  seedEmptyWaterAndFoods();
  seedMealRanges([]);
  seedWeeklyDigest();
}

describe("Progress", () => {
  beforeEach(() => {
    resetMocks();
  });

  it("показывает скелетон, пока данные не загрузились", () => {
    renderWithRouter(<Progress />);
    expect(screen.queryByText("Тренды")).not.toBeInTheDocument();
  });

  it("без профиля предлагает настроить его", () => {
    setQuery(api.profiles.getMyProfile, undefined, null);
    setQuery(api.weightEntries.listMyWeights, { limit: 730 }, []);
    setQuery(api.workouts.listLogs, { limit: 500 }, []);
    seedEmptyWaterAndFoods();
    seedMealRanges([]);
    seedWeeklyDigest();
    renderWithRouter(<Progress />);

    expect(
      screen.getByText("Настройте профиль, чтобы видеть цели на графиках."),
    ).toBeInTheDocument();
  });

  it("с пустыми данными показывает пустые состояния всех графиков и статы", () => {
    setupEmpty();
    renderWithRouter(<Progress />);

    expect(screen.getByRole("heading", { name: "Тренды" })).toBeInTheDocument();
    // В профиле есть targetWeightKg (75) — пустое состояние с упоминанием цели.
    expect(
      screen.getByText("Записывайте вес, чтобы увидеть путь к цели 75.0 кг."),
    ).toBeInTheDocument();
    expect(
      screen.getByText("Записывайте приёмы пищи в дневнике — здесь появится линия калорий."),
    ).toBeInTheDocument();
    expect(
      screen.getByText("Записывайте еду — макросы по дням появятся здесь."),
    ).toBeInTheDocument();
    expect(
      screen.getByText("Запишите первую тренировку из плана — появится недельная активность."),
    ).toBeInTheDocument();

    // Статы: нули по всем четырём метрикам.
    expect(screen.getByText("Средние калории")).toBeInTheDocument();
    expect(screen.getByText("Приёмов пищи")).toBeInTheDocument();
    expect(screen.getByText("Тренировок")).toBeInTheDocument();
    expect(screen.getByText("Замеров веса")).toBeInTheDocument();
    // Кнопки экспорта показывают количество записей — все пять типов.
    expect(screen.getByRole("button", { name: /Вес \(0\)/ })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Питание \(0\)/ })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Тренировки \(0\)/ })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Вода \(0\)/ })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Продукты \(0\)/ })).toBeInTheDocument();
  });

  it("с данными рисует графики: вес, калории, макросы, дельту и прогноз", () => {
    const now = new Date();
    const recent: WeightEntry[] = [
      weightEntry(toDateKey(new Date(now.getTime() - 14 * 86400000)), 82),
      weightEntry(toDateKey(new Date(now.getTime() - 7 * 86400000)), 81),
      weightEntry(todayKey(), 80),
    ];
    setQuery(api.profiles.getMyProfile, undefined, profile);
    setQuery(api.weightEntries.listMyWeights, { limit: 730 }, recent);
    setQuery(api.workouts.listLogs, { limit: 500 }, []);
    seedEmptyWaterAndFoods();
    const meals = [
      mealEntry("m1", toDateKey(new Date(now.getTime() - 1 * 86400000)), 500),
      mealEntry("m2", todayKey(), 700),
    ];
    seedMealRanges(meals);
    seedWeeklyDigest();
    renderWithRouter(<Progress />);

    // Заголовки графиков.
    for (const title of ["Вес", "Калории", "Макросы", "Тренировки"]) {
      expect(screen.getByText(title)).toBeInTheDocument();
    }
    // Дельта веса: 82 → 80 = −2.0 кг.
    expect(screen.getByText(/−?2\.0 кг/)).toBeInTheDocument();
    // Прогноз (в профиле targetWeightKg = 75) — карточка «Прогноз по текущему темпу».
    expect(screen.getByText("Прогноз по текущему темпу")).toBeInTheDocument();
    expect(screen.getByText(/75\.0 кг — около/)).toBeInTheDocument();
    // Статы с данными: 2 приёма пищи, 3 замера.
    expect(screen.getByRole("button", { name: "Питание (2)" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Вес (3)" })).toBeInTheDocument();
  });

  it("переключение периода меняет подписи и пересчитывает диапазон", async () => {
    const user = userEvent.setup();
    setupEmpty();
    renderWithRouter(<Progress />);

    // По умолчанию 30 дней.
    expect(screen.getByText(/Замеры за 30 дн\./)).toBeInTheDocument();

    // Переключение на 7 дней.
    await user.click(screen.getByText("7 дней"));
    expect(screen.getByText(/Замеры за 7 дн\./)).toBeInTheDocument();
    expect(screen.getByText(/Последние 7 дней против цели/)).toBeInTheDocument();
  });

  it("кнопки экспорта запускают скачивание CSV (URL-стаб в setup)", async () => {
    const user = userEvent.setup();
    const createUrl = vi.spyOn(URL, "createObjectURL");
    setupEmpty();
    renderWithRouter(<Progress />);

    await user.click(screen.getByRole("button", { name: /Вес \(0\)/ }));

    expect(createUrl).toHaveBeenCalledTimes(1);
    const blob = createUrl.mock.calls[0][0] as Blob;
    expect(blob).toBeInstanceOf(Blob);
    expect(blob.type).toContain("text/csv");
  });

  it("тренд вверх показывает плюс-дельту", () => {
    const now = new Date();
    setQuery(api.profiles.getMyProfile, undefined, profile);
    setQuery(api.weightEntries.listMyWeights, { limit: 730 }, [
      weightEntry(toDateKey(new Date(now.getTime() - 7 * 86400000)), 78),
      weightEntry(todayKey(), 79.5),
    ]);
    setQuery(api.workouts.listLogs, { limit: 500 }, []);
    seedEmptyWaterAndFoods();
    seedMealRanges([]);
    seedWeeklyDigest();
    renderWithRouter(<Progress />);

    expect(screen.getByText("+1.5 кг")).toBeInTheDocument();
  });

  it("вес, прошедший цель, показывает зелёное состояние «цель достигнута»", () => {
    const now = new Date();
    // Старт 82 кг, цель 75 — текущий 74 кг прошёл цель: путь 82→74 = 8 из 7 кг →
    // перебор ~14%.
    setQuery(api.profiles.getMyProfile, undefined, profile);
    setQuery(api.weightEntries.listMyWeights, { limit: 730 }, [
      weightEntry(toDateKey(new Date(now.getTime() - 14 * 86400000)), 82),
      weightEntry(todayKey(), 74),
    ]);
    setQuery(api.workouts.listLogs, { limit: 500 }, []);
    seedEmptyWaterAndFoods();
    seedMealRanges([]);
    seedWeeklyDigest();
    renderWithRouter(<Progress />);

    // Кольцо сигналит превышение (цель достигнута и пройдена дальше).
    expect(
      screen.getByRole("img", { name: "Превышение на 14%" }),
    ).toBeInTheDocument();
    // Внутри кольца: «+14%» и подпись «цель достигнута» (зелёная, не красная).
    const over = screen.getByText("+14%");
    expect(over.style.color).toBe("var(--macro-over)");
    expect(screen.getByText("цель достигнута")).toBeInTheDocument();
  });

  it("итоги недели: с данными рисует плитки и AI-разбор", () => {
    setupEmpty();
    setQuery(api.digest.getMyWeeklyDigest, undefined, {
      hasData: true,
      trackedDays: 5,
      weightStartKg: 80.0,
      weightEndKg: 79.3,
      weightDeltaKg: -0.7,
      avgCalories: 2000,
      avgProteinG: 120,
      caloriePct: 91,
      workoutCount: 3,
      tonnageKg: 4000,
      avgWaterMl: 2100,
    });
    renderWithRouter(<Progress />);

    expect(screen.getByText("Итоги за 7 дней")).toBeInTheDocument();
    // Плитки: дельта веса, тренировки с целью, активность.
    expect(screen.getByText("-0.7 кг")).toBeInTheDocument();
    expect(screen.getByText("из 3 за неделю")).toBeInTheDocument();
    expect(screen.getByText("91%")).toBeInTheDocument();
    expect(screen.getByText("5/7")).toBeInTheDocument();
    // AI-разбор: похудение −0,7 кг → совет про белок.
    expect(screen.getByText(/темп хороший/)).toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: "Спросить коуча" }),
    ).toBeInTheDocument();
    // «На следующей неделе»: тренировки закрыты (3 из 3), белок 120 из 152 г
    // → следующий шаг — прибавить белок.
    expect(screen.getByText(/На следующей неделе/)).toBeInTheDocument();
    expect(screen.getByText(/Увеличьте белок до 152 г/)).toBeInTheDocument();
  });

  it("итоги недели: без данных показывает подсказку начать", () => {
    setupEmpty();
    renderWithRouter(<Progress />);

    expect(screen.getByText("Итоги за 7 дней")).toBeInTheDocument();
    expect(
      screen.getByText(/Неделя начинается с первой записи/),
    ).toBeInTheDocument();
  });
});
